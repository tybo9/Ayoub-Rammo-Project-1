//Raegeorge Decastro, Ayoub Rammo
//SSH username: cssc4203, cssc4209 
//Class: CS-570,  Summer 2021 
//Programming Assignment #1


#include <fstream>
#include <unistd.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include <semaphore.h>
#include <pthread.h>
#include <cstdlib>

using namespace std;
#define NUM_THREADS 7

  sem_t FLAG; //using semaphore object
  ofstream file; //declare a file object
  ofstream quote;

  void *doWork(void *args) //thread task function, to write to QOUTE.txt
  {
    string str_quote = " ";
    int id = (*(int*)args);

      if (id % 2 == 0){   //id is even 

          sleep(2);
          sem_wait(&FLAG); //WAIT
          str_quote = " Controlling complexity is the essence of computer programming.\n --Brian Kernigan";
          cout<<"thread "<<id<<" is working\n";
          file << "thread " << id << str_quote <<"\r\n"; //write qoute in the text file
          sem_post(&FLAG);//SIGNAL
          
          
      }
      else{ //id is odd

          sleep(3);
          sem_wait(&FLAG);//WAIT
          str_quote = " Computer science is no more about computers than astronomy is about telescopes.\n--Edsger Dijkstra";
          cout<<"thread "<<id<<" is working\n";
          file << "thread " << id << str_quote <<"\r\n"; //write qoute in text the file
          sem_post(&FLAG);//SIGNAL
      }
    
  }
  
int main(){

    pthread_t threads[NUM_THREADS]; //declaring a thread object
    sem_init(&FLAG,0,1); //initializing semaphore

    file.open("QOUTE.txt",ios::app); //append qoutes into the file text instead of overwriting

    for(int i = 1; i <= NUM_THREADS; i++){ //loop to create 7 threads
        pthread_create(&threads[i], NULL, doWork, &i);
        cout<<"thread "<<i<<" is created in main\n";
    }
    for(int i = 1; i <= NUM_THREADS; i++){ //loop to join thread once every thread is done
       pthread_join(threads[i], NULL);
       cout<<"thread "<<i<<" is finished\n";
    }
    file.close();
    sem_destroy(&FLAG); //POSIX destroy the semaphore
    cout<< "Program Completed";
    
}