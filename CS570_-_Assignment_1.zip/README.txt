﻿ReadMe - Programming Assignment 1
SDSU Summer 2021: CS 570 - 01
Names: Ayoub Rammo, Rageorge Decastro
Edoras(SSH) : cssc4209 , cssc4203
Programming Assignment 1
Motivation: To understand the idea of threads and how multiple threads run concurrently and how to manage them so that only one thread can open/write/close using semaphores.
File manifest: This project includes source code written in C++, a ReadMe.txt and a makefile
Task breakdown: Ayoub is in charge of implementing the source code. Raegeorge gets the source code updates everyday so that he can check for correctness and improvement before submission as well as debugging the program. Each group member bounced Ideas back and forth to make sure that our code is simple but sufficient as well as easy to read.